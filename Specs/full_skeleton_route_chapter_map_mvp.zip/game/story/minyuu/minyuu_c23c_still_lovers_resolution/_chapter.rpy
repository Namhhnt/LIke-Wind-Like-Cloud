# FILE: game/story/minyuu/minyuu_c23c_still_lovers_resolution/_chapter.rpy
# Chapter wrapper. Calls scene labels only; no heavy story content here.

label minyuu_c23c_still_lovers_resolution:
    call minyuu_c23c_still_lovers_resolution_s01_define_relationship
    call minyuu_c23c_still_lovers_resolution_s02_private_public_non_marriage
    call minyuu_c23c_still_lovers_resolution_s03_future_shape
    $ story_complete_chapter('minyuu_c23c_still_lovers_resolution')
    if renpy.has_label('route_map'):
        jump route_map
    return
