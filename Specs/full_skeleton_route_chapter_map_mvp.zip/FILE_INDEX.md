# Full Skeleton Route Chapter Map MVP

Copy the `game/` folder contents into your Ren'Py project.

## Core files
- `game/story_state.rpy`
- `game/ending_rules.rpy`
- `game/progression_data_route_skeleton.rpy`
- `game/story/endings/ending_resolver.rpy`

## Chapter and scene files
- `game/story/prologue/prologue_rain_dream/_chapter.rpy`
- `game/story/tam/tam_c01_interview_day/_chapter.rpy`
- `game/story/tam/tam_c02_company_party/_chapter.rpy`
- `game/story/tam/tam_c03_thienan_family/_chapter.rpy`
- `game/story/hoang/hoang_h01_brother_house/_chapter.rpy`
- `game/story/tam/tam_c05_sunday_date/_chapter.rpy`
- `game/story/tam/tam_c06_minh_returns/_chapter.rpy`
- `game/story/tam/tam_c07_minh_at_company/_chapter.rpy`
- `game/story/yuuka/yuuka_c08_festival_arrival/_chapter.rpy`
- `game/story/flashback_minyuu/fb_minyuu_01_first_frame/_chapter.rpy`
- `game/story/flashback_minyuu/fb_minyuu_02_working_rhythm/_chapter.rpy`
- `game/story/flashback_minyuu/fb_minyuu_03_door_left_open/_chapter.rpy`
- `game/story/flashback_minyuu/fb_minyuu_04a_old_friends/_chapter.rpy`
- `game/story/flashback_minyuu/fb_minyuu_04b_living_together/_chapter.rpy`
- `game/story/flashback_minyuu/fb_minyuu_05b_separation/_chapter.rpy`
- `game/story/flashback_minyuu/fb_minyuu_04c_no_breakup/_chapter.rpy`
- `game/story/yuuka/yuuka_c09_yuukas_work/_chapter.rpy`
- `game/story/work/work_c10_project_festival_overlap/_chapter.rpy`
- `game/story/group/group_c11_social_dinner/_chapter.rpy`
- `game/story/work/work_c16_project_crisis/_chapter.rpy`
- `game/story/hoang/hoang_h05_shadow_of_minh/_chapter.rpy`
- `game/story/yuuka/yuuka_c18a_career_interlude/_chapter.rpy`
- `game/story/yuuka/yuuka_c18b_habit_of_you/_chapter.rpy`
- `game/story/yuuka/yuuka_c18c_long_distance_interlude/_chapter.rpy`
- `game/story/minyuu/c19a_city_after_festival_old_friends/_chapter.rpy`
- `game/story/minyuu/c19b_city_after_festival_ex_lovers/_chapter.rpy`
- `game/story/minyuu/c19c_city_after_festival_still_lovers/_chapter.rpy`
- `game/story/tam/tam_c20a_tam_minh_possible/_chapter.rpy`
- `game/story/tam/tam_c20b_admiration_vs_love/_chapter.rpy`
- `game/story/thienan/thienan_c21a_minh_possible/_chapter.rpy`
- `game/story/thienan/thienan_c21b_choose_own_path/_chapter.rpy`
- `game/story/huyen/huyen_c22_quan_or_hoang/_chapter.rpy`
- `game/story/minyuu/minyuu_c23a_old_friends_resolution/_chapter.rpy`
- `game/story/minyuu/minyuu_c23b_ex_lovers_resolution/_chapter.rpy`
- `game/story/minyuu/minyuu_c23c_still_lovers_resolution/_chapter.rpy`
- `game/story/final/final_c24_last_choices/_chapter.rpy`

Each chapter wrapper calls 3-5 scene labels. Scene files are intentionally minimal and interaction-focused.
