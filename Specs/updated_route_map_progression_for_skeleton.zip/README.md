# Updated progression files for skeleton MVP

Copy these into `game/` replacing the current files:

- `route_map.rpy`
- `progression_data.rpy`
- `progression_logic.rpy`

These files expect the skeleton scene package to also include:

- `story_state.rpy`
- `ending_rules.rpy`
- `story/**` scene files

Important ID change: the old prototype chapter IDs (`tam_c01`, `tam_c02`, `hoang_h01`) are replaced by full skeleton IDs (`tam_c01_interview_day`, `tam_c02_company_party`, `hoang_h01_brother_house`, etc.).
